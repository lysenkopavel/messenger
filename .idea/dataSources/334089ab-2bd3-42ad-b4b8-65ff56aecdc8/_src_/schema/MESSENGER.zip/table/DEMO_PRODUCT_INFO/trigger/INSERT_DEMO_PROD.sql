CREATE TRIGGER INSERT_DEMO_PROD
BEFORE INSERT
  ON DEMO_PRODUCT_INFO
FOR EACH ROW
  DECLARE
  prod_id number;
BEGIN
  SELECT demo_prod_seq.nextval
    INTO prod_id
    FROM dual;
  :new.PRODUCT_ID := prod_id;
END;
/
